# Changelog

All notable changes to DepCast will be documented in this file.

## [1.0.0] — 2026-05-22

### Added

- **CLI tool** — `depcast score`, `depcast check`, `depcast list`, `depcast pipeline` commands for terminal-based CRS computation and dataset querying.
- **Python package** — installable via `pip install -e .` with `depcast.crs` module exposing `compute_crs()` and `rate_crs()` as a public API.
- **Test suite** — 22 pytest tests covering CRS computation, rating thresholds, input validation, default weight invariants, and CLI behavior.
- **CI/CD** — GitHub Actions workflow running tests across Python 3.9–3.12 with linting, coverage reporting, and package build verification.
- **Docker support** — Dockerfile for reproducible pipeline execution.
- **Package configuration** — `pyproject.toml` replacing ad-hoc script execution with a proper Python package structure.

### Changed

- Extracted core CRS logic from `scripts/05_compute_crs_validation.py` into `depcast/crs.py` as a reusable, testable module.
- Reorganized project from a flat script collection into a proper Python package with `depcast/` source directory.

### Research (unchanged from v0.5)

- 51 confirmed breaking npm releases (2013–2023) with propagation analysis.
- 40 non-breaking control releases for AUC-ROC validation.
- SIR epidemiological model fitting (median R₀=1.42, n=44).
- CRS weighted scoring with AUC-ROC=1.000 on 91-release dataset.
- 1,275+ automated candidates from npm deprecation sweep.

## [0.5.0] — 2026-04-15

### Added

- Initial research pipeline: 8 Python scripts for data collection, analysis, and validation.
- Breaking releases dataset (51 confirmed npm releases).
- Non-breaking controls dataset (40 verified releases).
- SIR model fitting and propagation analysis.
- CRS computation and validation with publication-quality figures.
- README with full methodology, results, and research agenda.
