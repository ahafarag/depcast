"""
DepCast — A Two-Sided Compatibility Intelligence Protocol
for Software Package Ecosystems.
"""

__version__ = "1.0.0"

from depcast.crs import compute_crs, rate_crs

__all__ = ["compute_crs", "rate_crs", "__version__"]
