"""
Core Compatibility Risk Score (CRS) computation.

CRS(t) = w1*V(r) + w2*E(r) + w3*D(t) + w4*H(m)

Where:
    V(r) — API surface volatility (proportion of exported symbols removed)
    E(r) — Downstream exposure (weighted dependent package count)
    D(t) — Observed failure rate (CI failures from early adopters)
    H(m) — Maintainer history (exponentially weighted prior R0 values)
"""

from dataclasses import dataclass
from typing import Optional

# Default weights learned via logistic regression on the 91-release dataset
DEFAULT_WEIGHTS = {
    "V_r": 0.335,
    "E_r": 0.035,
    "D_t": 0.584,
    "H_m": 0.046,
}

# CRS rating thresholds
SAFE_THRESHOLD = 0.25
AVOID_THRESHOLD = 0.60


@dataclass
class CRSResult:
    """Result of a CRS computation."""

    score: float
    rating: str
    V_r: float
    E_r: float
    D_t: float
    H_m: float
    weights: dict

    def __str__(self) -> str:
        return (
            f"CRS={self.score:.3f} [{self.rating}] "
            f"(V={self.V_r:.3f}, E={self.E_r:.3f}, "
            f"D={self.D_t:.3f}, H={self.H_m:.3f})"
        )


def rate_crs(score: float) -> str:
    """
    Convert a CRS score to a human-readable rating.

    Returns:
        'SAFE'  if score <= 0.25
        'WAIT'  if 0.25 < score <= 0.60
        'AVOID' if score > 0.60
    """
    if score <= SAFE_THRESHOLD:
        return "SAFE"
    elif score <= AVOID_THRESHOLD:
        return "WAIT"
    else:
        return "AVOID"


def compute_crs(
    V_r: float = 0.0,
    E_r: float = 0.0,
    D_t: float = 0.0,
    H_m: float = 0.0,
    weights: Optional[dict] = None,
) -> CRSResult:
    """
    Compute the Compatibility Risk Score for a release.

    All input features should be normalized to [0, 1].

    Args:
        V_r: API surface volatility score.
        E_r: Downstream exposure score.
        D_t: Observed failure rate score.
        H_m: Maintainer history score.
        weights: Optional dict overriding default learned weights.

    Returns:
        CRSResult with score, rating, and component breakdown.

    Raises:
        ValueError: If any feature is outside [0, 1].
    """
    for name, val in [("V_r", V_r), ("E_r", E_r), ("D_t", D_t), ("H_m", H_m)]:
        if not (0.0 <= val <= 1.0):
            raise ValueError(
                f"{name}={val} is outside the valid range [0, 1]. "
                "Normalize features before computing CRS."
            )

    w = weights if weights is not None else DEFAULT_WEIGHTS

    score = (
        w.get("V_r", 0.335) * V_r
        + w.get("E_r", 0.035) * E_r
        + w.get("D_t", 0.584) * D_t
        + w.get("H_m", 0.046) * H_m
    )

    # Clamp to [0, 1] in case custom weights push it out of range
    score = max(0.0, min(1.0, score))

    return CRSResult(
        score=score,
        rating=rate_crs(score),
        V_r=V_r,
        E_r=E_r,
        D_t=D_t,
        H_m=H_m,
        weights=w,
    )
