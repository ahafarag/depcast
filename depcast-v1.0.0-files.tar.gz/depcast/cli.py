"""
DepCast CLI — check compatibility risk for npm packages.

Usage:
    depcast check <package>@<version>
    depcast score --V 0.8 --D 0.6 --E 0.1 --H 0.2
    depcast pipeline            # run full analysis pipeline
    depcast --version
"""

import argparse
import csv
import os
import sys
from pathlib import Path

from depcast import __version__
from depcast.crs import compute_crs, rate_crs


RATING_COLORS = {
    "SAFE": "\033[92m",   # green
    "WAIT": "\033[93m",   # yellow
    "AVOID": "\033[91m",  # red
}
RESET = "\033[0m"


def colored_rating(rating: str) -> str:
    """Return a terminal-colored rating string."""
    color = RATING_COLORS.get(rating, "")
    return f"{color}{rating}{RESET}"


def cmd_score(args):
    """Compute CRS from manually provided feature values."""
    result = compute_crs(
        V_r=args.V,
        E_r=args.E,
        D_t=args.D,
        H_m=args.H,
    )
    print(f"\n  CRS Score:  {result.score:.3f}")
    print(f"  Rating:     {colored_rating(result.rating)}")
    print(f"  Components: V(r)={result.V_r:.3f}  E(r)={result.E_r:.3f}  "
          f"D(t)={result.D_t:.3f}  H(m)={result.H_m:.3f}")

    if result.rating == "SAFE":
        print("\n  → Proceed with upgrade.\n")
    elif result.rating == "WAIT":
        print("\n  → Delay 24–48h and monitor telemetry.\n")
    else:
        print("\n  → Pin to prior version and await patch.\n")


def cmd_check(args):
    """Look up a package@version in the local CRS scores dataset."""
    crs_path = Path("data/crs_scores.csv")
    if not crs_path.exists():
        print(f"  Error: {crs_path} not found.")
        print("  Run 'depcast pipeline' first to generate scores.")
        sys.exit(1)

    # Parse package@version
    if "@" not in args.target:
        print("  Error: specify package@version (e.g., chalk@5.0.0)")
        sys.exit(1)

    pkg, ver = args.target.rsplit("@", 1)

    with open(crs_path, newline="") as f:
        reader = csv.DictReader(f)
        for row in reader:
            if row.get("package", "").strip() == pkg and row.get("breaking_version", "").strip() == ver:
                score = float(row.get("CRS_equal", 0))
                rating = rate_crs(score)
                print(f"\n  Package:    {pkg}@{ver}")
                print(f"  CRS Score:  {score:.3f}")
                print(f"  Rating:     {colored_rating(rating)}")
                v = float(row.get("V_r", 0))
                e = float(row.get("E_r", 0))
                d = float(row.get("D_t", 0))
                h = float(row.get("H_m", 0))
                print(f"  Components: V(r)={v:.3f}  E(r)={e:.3f}  "
                      f"D(t)={d:.3f}  H(m)={h:.3f}\n")
                return

    print(f"\n  {pkg}@{ver} not found in dataset.")
    print("  Available packages can be listed with: depcast list\n")


def cmd_list(args):
    """List all scored releases in the dataset."""
    crs_path = Path("data/crs_scores.csv")
    if not crs_path.exists():
        print(f"  Error: {crs_path} not found.")
        print("  Run 'depcast pipeline' first to generate scores.")
        sys.exit(1)

    with open(crs_path, newline="") as f:
        reader = csv.DictReader(f)
        rows = list(reader)

    if not rows:
        print("  No scored releases found.")
        return

    print(f"\n  {'Package':<25} {'Version':<12} {'CRS':>6}  {'Rating':<6}")
    print(f"  {'─' * 25} {'─' * 12} {'─' * 6}  {'─' * 6}")

    for row in sorted(rows, key=lambda r: float(r.get("CRS_equal", 0)), reverse=True):
        pkg = row.get("package", "?")[:24]
        ver = row.get("breaking_version", "?")[:11]
        score = float(row.get("CRS_equal", 0))
        rating = rate_crs(score)
        print(f"  {pkg:<25} {ver:<12} {score:>6.3f}  {colored_rating(rating)}")

    print(f"\n  Total: {len(rows)} releases\n")


def cmd_pipeline(args):
    """Run the full DepCast analysis pipeline."""
    scripts_dir = Path("scripts")
    if not scripts_dir.exists():
        print("  Error: scripts/ directory not found.")
        print("  Run from the DepCast repository root.")
        sys.exit(1)

    pipeline = [
        ("00_fix_npm_metadata.py", "Patching npm metadata"),
        ("01_collect_breaking_releases.py", "Collecting breaking releases"),
        ("02_compute_api_volatility.py", "Computing API volatility"),
        ("04_fit_sir_model.py", "Fitting SIR propagation model"),
        ("06_collect_nonbreaking_controls.py", "Collecting non-breaking controls"),
        ("05_compute_crs_validation.py", "Computing CRS scores and validation"),
    ]

    for script, desc in pipeline:
        path = scripts_dir / script
        if not path.exists():
            print(f"  ⚠  Skipping {script} (not found)")
            continue
        print(f"\n  ▶  {desc} ({script})")
        ret = os.system(f"{sys.executable} {path}")
        if ret != 0:
            print(f"  ✗  {script} failed with exit code {ret}")
            if not args.force:
                sys.exit(1)

    print("\n  ✓  Pipeline complete. Results in data/crs_scores.csv\n")


def main():
    parser = argparse.ArgumentParser(
        prog="depcast",
        description="DepCast — Compatibility Risk Scoring for npm packages",
    )
    parser.add_argument(
        "--version", action="version", version=f"depcast {__version__}"
    )
    subparsers = parser.add_subparsers(dest="command", help="Available commands")

    # depcast score
    p_score = subparsers.add_parser(
        "score", help="Compute CRS from feature values"
    )
    p_score.add_argument("--V", type=float, default=0.0, help="V(r) API volatility [0-1]")
    p_score.add_argument("--E", type=float, default=0.0, help="E(r) downstream exposure [0-1]")
    p_score.add_argument("--D", type=float, default=0.0, help="D(t) observed failure rate [0-1]")
    p_score.add_argument("--H", type=float, default=0.0, help="H(m) maintainer history [0-1]")
    p_score.set_defaults(func=cmd_score)

    # depcast check
    p_check = subparsers.add_parser(
        "check", help="Look up CRS for a package@version"
    )
    p_check.add_argument("target", help="Package@version (e.g., chalk@5.0.0)")
    p_check.set_defaults(func=cmd_check)

    # depcast list
    p_list = subparsers.add_parser(
        "list", help="List all scored releases"
    )
    p_list.set_defaults(func=cmd_list)

    # depcast pipeline
    p_pipe = subparsers.add_parser(
        "pipeline", help="Run full analysis pipeline"
    )
    p_pipe.add_argument(
        "--force", action="store_true", help="Continue on script failure"
    )
    p_pipe.set_defaults(func=cmd_pipeline)

    args = parser.parse_args()
    if args.command is None:
        parser.print_help()
        sys.exit(0)

    args.func(args)


if __name__ == "__main__":
    main()
