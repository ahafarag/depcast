"""
Tests for depcast.cli — the command-line interface.
"""

import subprocess
import sys


def run_cli(*args):
    """Helper to run depcast CLI and capture output."""
    result = subprocess.run(
        [sys.executable, "-m", "depcast.cli", *args],
        capture_output=True,
        text=True,
    )
    return result


class TestCLIVersion:
    def test_version_flag(self):
        result = run_cli("--version")
        assert result.returncode == 0
        assert "depcast" in result.stdout.lower()


class TestCLIScore:
    def test_score_all_zeros(self):
        result = run_cli("score", "--V", "0", "--D", "0", "--E", "0", "--H", "0")
        assert result.returncode == 0
        assert "0.000" in result.stdout
        assert "SAFE" in result.stdout

    def test_score_high_risk(self):
        result = run_cli("score", "--V", "0.9", "--D", "1.0", "--E", "0.5", "--H", "0.3")
        assert result.returncode == 0
        assert "AVOID" in result.stdout

    def test_score_moderate_risk(self):
        result = run_cli("score", "--V", "0.3", "--D", "0.4", "--E", "0.1", "--H", "0.2")
        assert result.returncode == 0
        # Should be WAIT range


class TestCLIHelp:
    def test_no_args_shows_help(self):
        result = run_cli()
        assert result.returncode == 0
        assert "depcast" in result.stdout.lower() or "usage" in result.stdout.lower()
