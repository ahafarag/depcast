"""
Tests for depcast.crs — the core Compatibility Risk Score module.
"""

import pytest
from depcast.crs import compute_crs, rate_crs, CRSResult, DEFAULT_WEIGHTS


class TestRateCRS:
    """Tests for the CRS rating function."""

    def test_safe_at_zero(self):
        assert rate_crs(0.0) == "SAFE"

    def test_safe_at_boundary(self):
        assert rate_crs(0.25) == "SAFE"

    def test_wait_just_above_safe(self):
        assert rate_crs(0.26) == "WAIT"

    def test_wait_at_boundary(self):
        assert rate_crs(0.60) == "WAIT"

    def test_avoid_just_above_wait(self):
        assert rate_crs(0.61) == "AVOID"

    def test_avoid_at_max(self):
        assert rate_crs(1.0) == "AVOID"


class TestComputeCRS:
    """Tests for the CRS computation function."""

    def test_all_zeros_returns_safe(self):
        result = compute_crs(V_r=0.0, E_r=0.0, D_t=0.0, H_m=0.0)
        assert result.score == 0.0
        assert result.rating == "SAFE"

    def test_all_ones_returns_avoid(self):
        result = compute_crs(V_r=1.0, E_r=1.0, D_t=1.0, H_m=1.0)
        assert result.score == pytest.approx(1.0)
        assert result.rating == "AVOID"

    def test_d_t_dominant_weight(self):
        """D(t) has weight 0.584 — a high D(t) alone should push into WAIT or AVOID."""
        result = compute_crs(V_r=0.0, E_r=0.0, D_t=1.0, H_m=0.0)
        assert result.score == pytest.approx(0.584)
        assert result.rating == "WAIT"

    def test_v_r_secondary_weight(self):
        """V(r) has weight 0.335 — a high V(r) alone should push into WAIT."""
        result = compute_crs(V_r=1.0, E_r=0.0, D_t=0.0, H_m=0.0)
        assert result.score == pytest.approx(0.335)
        assert result.rating == "WAIT"

    def test_combined_v_and_d_is_avoid(self):
        """V(r)=1.0 + D(t)=1.0 should result in AVOID (0.335 + 0.584 = 0.919)."""
        result = compute_crs(V_r=1.0, E_r=0.0, D_t=1.0, H_m=0.0)
        assert result.score == pytest.approx(0.919)
        assert result.rating == "AVOID"

    def test_low_risk_release(self):
        """A release with minor volatility and no failures should be SAFE."""
        result = compute_crs(V_r=0.1, E_r=0.2, D_t=0.0, H_m=0.1)
        assert result.rating == "SAFE"
        assert result.score < 0.25

    def test_returns_crs_result_dataclass(self):
        result = compute_crs(V_r=0.5, E_r=0.5, D_t=0.5, H_m=0.5)
        assert isinstance(result, CRSResult)
        assert result.V_r == 0.5
        assert result.E_r == 0.5
        assert result.D_t == 0.5
        assert result.H_m == 0.5

    def test_custom_weights(self):
        """Custom weights should override defaults."""
        equal_weights = {"V_r": 0.25, "E_r": 0.25, "D_t": 0.25, "H_m": 0.25}
        result = compute_crs(V_r=1.0, E_r=1.0, D_t=1.0, H_m=1.0, weights=equal_weights)
        assert result.score == pytest.approx(1.0)

    def test_custom_weights_partial(self):
        """Equal weights on all-0.5 features should give 0.5."""
        equal_weights = {"V_r": 0.25, "E_r": 0.25, "D_t": 0.25, "H_m": 0.25}
        result = compute_crs(V_r=0.5, E_r=0.5, D_t=0.5, H_m=0.5, weights=equal_weights)
        assert result.score == pytest.approx(0.5)

    def test_score_clamped_to_unit_interval(self):
        """Even with extreme custom weights, score stays in [0, 1]."""
        big_weights = {"V_r": 2.0, "E_r": 2.0, "D_t": 2.0, "H_m": 2.0}
        result = compute_crs(V_r=1.0, E_r=1.0, D_t=1.0, H_m=1.0, weights=big_weights)
        assert result.score == 1.0

    def test_str_representation(self):
        result = compute_crs(V_r=0.8, E_r=0.1, D_t=0.9, H_m=0.2)
        s = str(result)
        assert "CRS=" in s
        assert result.rating in s


class TestInputValidation:
    """Tests for input validation."""

    def test_negative_v_r_raises(self):
        with pytest.raises(ValueError, match="V_r"):
            compute_crs(V_r=-0.1)

    def test_v_r_above_one_raises(self):
        with pytest.raises(ValueError, match="V_r"):
            compute_crs(V_r=1.1)

    def test_negative_d_t_raises(self):
        with pytest.raises(ValueError, match="D_t"):
            compute_crs(D_t=-0.5)

    def test_e_r_above_one_raises(self):
        with pytest.raises(ValueError, match="E_r"):
            compute_crs(E_r=2.0)


class TestDefaultWeights:
    """Tests for the default weight configuration."""

    def test_weights_sum_to_one(self):
        total = sum(DEFAULT_WEIGHTS.values())
        assert total == pytest.approx(1.0)

    def test_d_t_is_heaviest(self):
        assert DEFAULT_WEIGHTS["D_t"] > DEFAULT_WEIGHTS["V_r"]
        assert DEFAULT_WEIGHTS["D_t"] > DEFAULT_WEIGHTS["E_r"]
        assert DEFAULT_WEIGHTS["D_t"] > DEFAULT_WEIGHTS["H_m"]

    def test_all_four_features_present(self):
        assert set(DEFAULT_WEIGHTS.keys()) == {"V_r", "E_r", "D_t", "H_m"}
